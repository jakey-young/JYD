// Auto-generated. Do not edit!

// (in-package ADAS_AEB.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class aeb {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.velocity = null;
      this.steering_angle = null;
      this.acceleration = null;
      this.throttle = null;
      this.brake = null;
      this.distance_r = null;
      this.velocity_r = null;
      this.model = null;
    }
    else {
      if (initObj.hasOwnProperty('velocity')) {
        this.velocity = initObj.velocity
      }
      else {
        this.velocity = 0.0;
      }
      if (initObj.hasOwnProperty('steering_angle')) {
        this.steering_angle = initObj.steering_angle
      }
      else {
        this.steering_angle = 0.0;
      }
      if (initObj.hasOwnProperty('acceleration')) {
        this.acceleration = initObj.acceleration
      }
      else {
        this.acceleration = 0.0;
      }
      if (initObj.hasOwnProperty('throttle')) {
        this.throttle = initObj.throttle
      }
      else {
        this.throttle = 0.0;
      }
      if (initObj.hasOwnProperty('brake')) {
        this.brake = initObj.brake
      }
      else {
        this.brake = 0.0;
      }
      if (initObj.hasOwnProperty('distance_r')) {
        this.distance_r = initObj.distance_r
      }
      else {
        this.distance_r = 0.0;
      }
      if (initObj.hasOwnProperty('velocity_r')) {
        this.velocity_r = initObj.velocity_r
      }
      else {
        this.velocity_r = 0.0;
      }
      if (initObj.hasOwnProperty('model')) {
        this.model = initObj.model
      }
      else {
        this.model = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type aeb
    // Serialize message field [velocity]
    bufferOffset = _serializer.float64(obj.velocity, buffer, bufferOffset);
    // Serialize message field [steering_angle]
    bufferOffset = _serializer.float64(obj.steering_angle, buffer, bufferOffset);
    // Serialize message field [acceleration]
    bufferOffset = _serializer.float64(obj.acceleration, buffer, bufferOffset);
    // Serialize message field [throttle]
    bufferOffset = _serializer.float64(obj.throttle, buffer, bufferOffset);
    // Serialize message field [brake]
    bufferOffset = _serializer.float64(obj.brake, buffer, bufferOffset);
    // Serialize message field [distance_r]
    bufferOffset = _serializer.float64(obj.distance_r, buffer, bufferOffset);
    // Serialize message field [velocity_r]
    bufferOffset = _serializer.float64(obj.velocity_r, buffer, bufferOffset);
    // Serialize message field [model]
    bufferOffset = _serializer.float64(obj.model, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type aeb
    let len;
    let data = new aeb(null);
    // Deserialize message field [velocity]
    data.velocity = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [steering_angle]
    data.steering_angle = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [acceleration]
    data.acceleration = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [throttle]
    data.throttle = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [brake]
    data.brake = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [distance_r]
    data.distance_r = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [velocity_r]
    data.velocity_r = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [model]
    data.model = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 64;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ADAS_AEB/aeb';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c95388b37772764e8d34e2bd29b6e195';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # aeb.msg
    float64 velocity
    float64 steering_angle
    float64 acceleration
    float64 throttle
    float64 brake
    float64 distance_r
    float64 velocity_r
    float64 model
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new aeb(null);
    if (msg.velocity !== undefined) {
      resolved.velocity = msg.velocity;
    }
    else {
      resolved.velocity = 0.0
    }

    if (msg.steering_angle !== undefined) {
      resolved.steering_angle = msg.steering_angle;
    }
    else {
      resolved.steering_angle = 0.0
    }

    if (msg.acceleration !== undefined) {
      resolved.acceleration = msg.acceleration;
    }
    else {
      resolved.acceleration = 0.0
    }

    if (msg.throttle !== undefined) {
      resolved.throttle = msg.throttle;
    }
    else {
      resolved.throttle = 0.0
    }

    if (msg.brake !== undefined) {
      resolved.brake = msg.brake;
    }
    else {
      resolved.brake = 0.0
    }

    if (msg.distance_r !== undefined) {
      resolved.distance_r = msg.distance_r;
    }
    else {
      resolved.distance_r = 0.0
    }

    if (msg.velocity_r !== undefined) {
      resolved.velocity_r = msg.velocity_r;
    }
    else {
      resolved.velocity_r = 0.0
    }

    if (msg.model !== undefined) {
      resolved.model = msg.model;
    }
    else {
      resolved.model = 0.0
    }

    return resolved;
    }
};

module.exports = aeb;
