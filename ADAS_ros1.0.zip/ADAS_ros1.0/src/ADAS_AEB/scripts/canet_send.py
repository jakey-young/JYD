#!/usr/bin/env python3

import rospy
import socket
from ADAS_AEB.msg import aeb

msg = aeb()


def convert_to_hex(input):
    hex_string_max = "02 00 00 64 00 00"
    hex_string_min = "02 00 00 00 00 00"
    hex_value_max = int(hex_string_max.replace(" ", ""), 16)
    hex_value_min = int(hex_string_min.replace(" ", ""), 16)
    k = (hex_value_max - hex_value_min) / 100
    b = hex_value_min
    value = input * k + b
    hex_value = hex(int(value))[2:]
    return hex_value




def byte_splice(byte):
    byte_data1 = b'\x08\x00\x00\x01\x54\x00\x00'
    byte_data2 = byte
    concatenated_data = byte_data1 + byte_data2
    return concatenated_data

def can_send(send_brake):
    CANET_IP = "192.168.1.178"  # CANet通信IP
    CANET_PORT = 4001  # CANet端口号
    PC_IP = "192.168.1.102"  # 主机通信IP
    PC_PORT = 4001  # 主机端口号
    # Create a UDP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # Bind the socket to the PC IP and port
    rospy.loginfo(send_brake)
    sock.bind((PC_IP, PC_PORT))
    sock.sendto(send_brake, (CANET_IP,CANET_PORT))


def data_process(msg):
    brake = msg.brake
    hex_brake = convert_to_hex(brake)
    byte_brake = bytes.fromhex("0" + hex_brake)
    # print(byte_brake)
    send_brake =byte_splice(byte_brake)
    # print(send_brake)
    can_send(send_brake)
    

if __name__  == "__main__":
    rospy.init_node("canet_send")
    rospy.Subscriber("/AEB_decision",aeb,data_process)
    rospy.spin()