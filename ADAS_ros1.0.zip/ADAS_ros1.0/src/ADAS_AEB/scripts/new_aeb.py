#!/usr/bin/env python3

import rospy
import math
import numpy as np


from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
import pdb
from ADAS_AEB.msg import aeb
# Vehicle parameters
ANGLE_RANGE = 360          # Hokuyo 10LX has 270 degree scan.
DISTANCE_THRESHOLD = 5    # Distance threshold before collision (m)
VELOCITY = 0.05              # Maximum Velocity of the vehicle
TIME_THRESHOLD = [2.5,1.2]       # Time threshold before collision (s)
STEERING_ANGLE = 0          # Steering angle is uncontrolled
BREAKE_VALUE = 0.0
THROTTLE = 0
# P-Controller Parameters
kp_dist = 0.75 # initialize
kp_ttc = 0.5 # initialize
velocity = 0.0 
dist_error = 0.0
time_error = 0.0
brake = 0.0
pub = rospy.Publisher('/AEB_decision', aeb, queue_size=20)


def TTC_control(distance, velocity):
    msg = aeb()
    # global kp_ttc
    # global TIME_THRESHOLD
    # global VELOCITY
    # global STEERING_ANGLE
    # global BREAKE_VALUE
    # Calculate Time To Collision Error
    if velocity ==0.0:
        velocity = 0.1
    time = distance / velocity  # time to collision
    if time > TIME_THRESHOLD[0]:
        throttle = 0
        brake = 0

    elif time <= TIME_THRESHOLD[0] and time > TIME_THRESHOLD[1]:
        throttle = 0
        brake = 40
    elif time <= TIME_THRESHOLD[1]:
        throttle = 0
        brake = 100

    # rospy.loginfo("Time to collision in seconds is = ", time)
    # print("Vehicle velocity = ", velocity)
    

    msg.throttle = throttle
    msg.steering_angle = STEERING_ANGLE
    msg.brake = brake
    rospy.loginfo('AEB后油门开度：%s\nAEB后刹车值：%s' % (msg.throttle, msg.brake))
    pub.publish(msg)	

def lidar(data):
	# Complete the Callback. Get the distance and input it into the controller
    global THROTTLE
    distance = data.distance_r
    velocity = data.velocity_r
    if velocity < 0 or distance < DISTANCE_THRESHOLD:
        # Euclidean distance control
        TTC_control(distance, velocity)
    else:
        msg = aeb()
        msg.throttle = THROTTLE
        rospy.loginfo('AEB后油门开度：%s\nAEB后刹车值：%s' % (msg.throttle, msg.brake))
        pub.publish(msg)

def self_car_info(msg):
    global THROTTLE
    THROTTLE = msg.throttle
    rospy.loginfo("当前模式为：自动驾驶" if msg.model==68 else "当前模式为：人工驾驶")
     

if __name__ == '__main__':
    rospy.init_node("AEB")
    msg = aeb()
    print("AEB started")
    rospy.Subscriber("/can_throttle",aeb, self_car_info)

    rospy.Subscriber("/mmlidar_msg", aeb, lidar)

    rospy.spin()