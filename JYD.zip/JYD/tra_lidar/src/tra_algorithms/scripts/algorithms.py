#! /usr/bin/env python3
# -*- coding:UTF-8 -*-

import rospy
import numpy as np
import open3d as o3d
import sensor_msgs.point_cloud2 as pc2
from sensor_msgs.msg import PointCloud2


def callback(point_cloud):
    rospy.loginfo('已订阅/rslidar_points话题')

    # 读取点云数据，转换为numpy数组
    pointcloud = np.array(list(pc2.read_points(point_cloud, skip_nans=True)))
    # 将numpy数组转换为Open3D点云对象
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(pointcloud[:, :3])

    # 对点云进行体素下采样，减少点云数据量
    voxel_down_pcd = pcd.voxel_down_sample(voxel_size=0.02)
    # 输出原始点云的个数
    print('原点云个数为：%s' % np.array(voxel_down_pcd.points).shape[0])
    # 使用Open3D可视化原始点云
    rospy.loginfo('可视化原始点云...')
    o3d.visualization.draw_geometries([voxel_down_pcd])
    # 对体素下采样后的点云进行半径滤波，去除离群点
    rospy.loginfo('正在进行半径滤波...')
    cl, index = voxel_down_pcd.remove_radius_outlier(nb_points=10, radius=0.1)
    new_pcd = voxel_down_pcd.select_by_index(index)
    # 输出半径滤波后的点云个数
    print('半径滤波后的点云个数为：%s' % np.array(new_pcd.points).shape[0])
    # 使用Open3D可视化半径滤波后的点云
    rospy.loginfo('可视化滤波后点云...')
    o3d.visualization.draw_geometries([new_pcd])

    # 对滤波后的点云进行RANSAC平面分割，提取平面内点和平面外点
    rospy.loginfo('正在进行RANSAC平面分割...')
    distance_threshold = 0.2  # 内点到平面模型的最大距离
    ransac_n = 3  # 用于拟合平面的采样点数
    num_iterations = 1000  # 最大迭代次数

    # 返回模型系数plane_model和内点索引inliers，并赋值
    plane_model, inliers = new_pcd.segment_plane(distance_threshold, ransac_n, num_iterations)

    # 平面内点点云
    inlier_cloud = new_pcd.select_by_index(inliers)
    inlier_cloud.paint_uniform_color([0, 0, 1.0])  # 将平面内点标记为蓝色
    print(inlier_cloud)

    # 平面外点点云
    outlier_cloud = new_pcd.select_by_index(inliers, invert=True)
    outlier_cloud.paint_uniform_color([1.0, 0, 0])  # 将平面外点标记为红色
    print(outlier_cloud)

    # 可视化平面分割结果
    o3d.visualization.draw_geometries([inlier_cloud, outlier_cloud])

if __name__ == '__main__':
    # 初始化订阅节点
    rospy.init_node('open3d_processing')
    rospy.loginfo('准备订阅/rslidar_points话题')

    # 订阅雷达数据
    rospy.Subscriber('/rslidar_points', PointCloud2, callback)

    # 进入ROS消息循环
    rospy.spin()