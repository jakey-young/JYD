#! /usr/bin/env python3

import struct
import serial
import rospy
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Vector3

def parse_imu_data(data):

    # 解算linear_acceleration
    accel_x = struct.unpack('<i', data[12:16])[0] * 1e-5
    accel_y = struct.unpack('<i', data[16:20])[0] * 1e-5
    accel_z = struct.unpack('<i', data[20:24])[0] * 1e-5
    rospy.loginfo("accel_x = %.2f, accel_y = %.2f, accel_z = %.2f", accel_x, accel_y, accel_z)

    return accel_x, accel_y, accel_z

def receive_imu_data():

    # 初始化节点
    rospy.init_node("imu_model", anonymous = True)
    marker_pub = rospy.Publisher('/visualization_marker', Marker, queue_size = 10)

    # 开启串口
    serialport = serial.Serial()
    buffer = b""
    try:
        # 设置串口属性并开启串口
        serialport.port = "/dev/ttyUSB0"
        serialport.baudrate = 230400
        serialport.timeout = 0.1
        serialport.open()
    except serial.SerialException as e:
        rospy.logerr("Unable to open serial port")
        return -1

    # 检测串口是否已经打开，并给出提示信息
    if serialport.is_open:
        rospy.loginfo("Serial port initialized")
    else:
        return -1
    
    while not rospy.is_shutdown():
        # 处理串口发过来的数据
        data_size = serialport.in_waiting

        if data_size >= 40:
            buffer = serialport.read(data_size)

            imu_index = buffer.find(b'\x7E\x7E\x0C')
            gins_index = buffer.find(b'\xAC\xCA\x0C')

            # 处理IMU数据
            if imu_index != -1 and (gins_index == -1 or imu_index < gins_index):
                if len(buffer[imu_index:]) >= 40:
                    Accel_x, Accel_y, Accel_z = parse_imu_data(buffer[imu_index:imu_index + 40])
                    buffer = buffer[imu_index + 40:]
        
            # 创建一个Marker消息，表示线性加速度向量 
            marker = Marker()
            marker.header.frame_id = "/map"
            marker.type = marker.ARROW
            marker.action = marker.ADD
            marker.scale.x = 0.1 # 箭头的长度
            marker.scale.y = 0.2 # 箭头的宽度
            marker.scale.z = 0.2 # 箭头的高度
            marker.color.a = 1.0 # 不透明度
            marker.color.r = 1.0 # 红色分量
            marker.color.g = 0 # 绿色分量
            marker.color.b = 0 # 蓝色分量
            marker.pose.orientation.w = 1.0 # 箭头的朝向
            
            marker.points.append(Vector3(0, 0, 0)) # 箭头起点
            marker.points.append(Vector3(Accel_x, Accel_y, Accel_z)) # 箭头终点 
        
            # 发布Marker消息
            marker_pub.publish(marker)
            # rospy.loginfo(marker)

if __name__ == '__main__':
    try:
        receive_imu_data()
    except rospy.ROSInternalException:
        pass