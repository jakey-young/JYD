import serial
import time

# 创建串口对象
ser = serial.Serial('/dev/ttyUSB1', 9600)  # 将COM3替换为你的串口设备

# 发送命令函数
def send_command():
    command = [0x55, 0xAA, 0x01, 0x01, 0x01]
    ser.write(bytearray(command))

while True:
    # 发送命令
    send_command()
    time.sleep(0.1)

    # 等待数据返回
    if ser.in_waiting >= 13:
        # 读取返回的数据
        data = ser.read(13)

        # 提取超声波雷达测距结果
        distance1 = ((data[4] << 8) | data[5]) / 10
        distance2 = ((data[6] << 8) | data[7]) / 10
        distance3 = ((data[8] << 8) | data[9]) / 10
        distance4 = ((data[10] << 8) | data[11]) / 10

        # 输出十进制测距结果
        print("1号探头探测距离:", distance1, "cm")
        print("2号探头探测距离:", distance2, "cm")
        print("3号探头探测距离:", distance3, "cm")
        print("4号探头探测距离:", distance4, "cm")
        print("------------------")

    # 休眠300ms
    time.sleep(0.5)

# 关闭串口
ser.close()