#!/usr/bin/env python3
from ADAS_AEB.msg import aeb
import rospy
THROTTLE = 30
pub = rospy.Publisher('/throttle_signal', aeb, queue_size=10)

            
if __name__ == "__main__":
    rospy.init_node("throttle_contral")
    msg = aeb()
    msg.throttle = THROTTLE
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        pub.publish(msg)
        rate.sleep()  #休眠

