#!/usr/bin/env python3

import socket
import rospy
from ADAS_AEB.msg import aeb

rospy.init_node("canet_receive")
msg = aeb()
pub = rospy.Publisher('/can_info',aeb,queue_size=10)


CANET_IP = "192.168.1.178"
CANET_PORT = 4001
PC_IP = "192.168.1.102"
PC_PORT = 4001

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((PC_IP, PC_PORT))

while not rospy.is_shutdown():
    data, addr = sock.recvfrom(100)
    if len(data) >= 13:
        frame = {
                    'ID':int.from_bytes(data[1:5], byteorder='big'),
                    'data': data[5:13],
        }

        if frame['ID'] == 1282:
            car_model = frame['data'][0]
            gas_padal = frame['data'][3]
            msg.throttle = gas_padal
            msg.model = car_model
            # rospy.loginfo('AEB后油门开度：%s\nAEB后刹车值：%s' % (msg.throttle, msg.brake))
            pub.publish(msg)
sock.close()
