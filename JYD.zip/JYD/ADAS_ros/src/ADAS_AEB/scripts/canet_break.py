#!/usr/bin/env python3

import socket
import rospy
from ADAS_AEB.msg import aeb

rospy.init_node("canet_break")
msg = aeb()
pub = rospy.Publisher('/can_throttle', aeb, queue_size=10)


CANET_IP = "192.168.1.178"  # CANet通信IP
CANET_PORT = 4001  # CANet端口号
PC_IP = "192.168.1.102"  # 主机通信IP
PC_PORT = 4001  # 主机端口号

# Create a UDP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Bind the socket to the PC IP and port
sock.bind((PC_IP, PC_PORT))

while not rospy.is_shutdown():
    # Receive data from the CAN-to-Ethernet device
    data, addr = sock.recvfrom(100)  # Adjust buffer size if necessary

    # Check if the received message has a valid length for parsing
    if len(data) >= 13:
        # Parse the received data
        frame = {
            'ID': int.from_bytes(data[1:5], byteorder='big'),
            'data': data[5:13],
        }

        if frame['ID'] == 1282:
            # Parse and print the relevant information for ID 502
            # car_sates = (frame['data'][0] & 0x0C) >> 2
            car_model = frame['data'][0]
            gas_pedal = frame['data'][3]
            # print("Received ID 502: Car Sates =", car_model, "Gas Pedal =", gas_pedal)
            msg.model = car_model
            msg.throttle = gas_pedal
            # msg.model = car_model
            # rospy.loginfo('当前油门开度：%s',car_model)
            pub.publish(msg)


        # elif frame['ID'] == 1283:
        #     # Parse and print the relevant information for ID 503
        #     car_spd_l = int.from_bytes(frame['data'][:2], byteorder='big') * 0.1
        #     car_spd_r = int.from_bytes(frame['data'][2:4], byteorder='big') * 0.1
        #     print("Received ID 503: Car Speed (Left) =", car_spd_l, "Car Speed (Right) =", car_spd_r)

        # elif frame['ID'] == 322:
        #     # Parse and print the relevant information for ID 111
        #     real_steer_ang = ((frame['data'][3] * 256 + frame['data'][4]) - 1024)
        #     print("Received ID 111: Real Steer Angle =", real_steer_ang)

# Close the socket (this will not be reached in this example)
sock.close()