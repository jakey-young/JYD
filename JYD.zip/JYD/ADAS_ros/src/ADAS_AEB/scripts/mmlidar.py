#!/usr/bin/env python3


import socket
import rospy
from ADAS_AEB.msg import aeb
import  math
rospy.init_node("mmlidar")
msg = aeb()
pub = rospy.Publisher('/mmlidar_msg', aeb, queue_size=10)
 

CANET_IP = "192.168.1.178"  # CANet通信IP
CANET_PORT = 4002  # CANet端口号
PC_IP = "192.168.1.102"  # 主机通信IP
PC_PORT = 8002  # 主机端口号

# Create a UDP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Bind the socket to the PC IP and port
sock.bind((PC_IP, PC_PORT))
front={}
front2={}
i=0
while not rospy.is_shutdown():
    # Receive data from the CAN-to-Ethernet device
    data, addr = sock.recvfrom(1024)  # Adjust buffer size if necessary

    # Check if the received message has a valid length for parsing
    if len(data) >= 13:
        # Parse the received data
        frame = {
            'ID': int.from_bytes(data[1:5], byteorder='big'),
            'data': data[5:13],
        }

        if frame['ID'] == 1547:
    
            
            x=((int(frame['data'][1])<< 5) + (int(frame['data'][2]) >> 3))*0.2 - 500.0
            y=((int(frame['data'][2] & 0b111) << 8) + int(frame['data'][3]))*0.2 - 204.6
            v_x=((int(frame['data'][4]) << 2) + (int(frame['data'][5]) >> 6))*0.25 - 128.00
            sita = math.degrees(math.atan(abs(y)/(x+0.001)))
            # print(f"该物体的纵坐标为:{x},该物体的横坐标为:{y},该物体的纵向速度为:{v_x}")
            front2[i]=x
            front[x]=[y,v_x,sita]
            
            i=i+1
            if i%30==0:
                x_values = [data for data in front.keys()]
                x = min(x_values)
                if front[x][2] <20:
                    print(f"距离本车最近的目标的位置是前方{x},此刻它相对于本车的速度为{front[x][1]}")
                    msg.distance_r=x
                    msg.velocity_r=front[x][1]
                    pub.publish(msg)
                    front={}
            
# Close the socket (this will not be reached in this example)
sock.close()

# import socket
# import rospy
# from glosa.msg import glosa
# import math
# rospy.init_node("mmlidar")
# msg = glosa()
# pub = rospy.Publisher('/mmlidar_msg', glosa, queue_size=10)
             

# CANET_IP = "192.168.1.178"  # CANet通信IP
# CANET_PORT = 4002  # CANet端口号
# PC_IP =  "192.168.1.102"  # 主机通信IP
# PC_PORT = 8002  # 主机端口号

# # Create a UDP socket
# sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# # Bind the socket to the PC IP and port
# sock.bind((PC_IP, PC_PORT))
# front={}
# front2={}
# i=0
# while True:
#     # Receive data from the CAN-to-Ethernet device
#     data, addr = sock.recvfrom(1024)  # Adjust buffer size if necessary

#     # Check if the received message has a valid length for parsing
#     if len(data) >= 13:
#         # Parse the received data
#         frame = {
#             'ID': int.from_bytes(data[1:5], byteorder='big'),
#             'data': data[5:13],
#         }

#         if frame['ID'] == 1547:
    
            
#             x=((int(frame['data'][1])<< 5) + (int(frame['data'][2]) >> 3))*0.2 - 500.0
#             y=((int(frame['data'][2] & 0b111) << 8) + int(frame['data'][3]))*0.2 - 204.6
#             v_x=((int(frame['data'][4]) << 2) + (int(frame['data'][5]) >> 6))*0.25 - 128.00
#             sita = math.degrees(math.atan(abs(y)/x))
#             # print(f"该物体的纵坐标为:{x},该物体的横坐标为:{y},该物体的纵向速度为:{v_x}")
         
#             front[x]=[y,v_x,sita]
            
#             i=i+1
#             if i%30==0:
#                 x_values = [data for data in front.keys()]
#                 x = min(x_values)
#                 if front[x][2] <20:
#                     rospy.loginfo(f"距离本车最近的目标的位置是前方{x},此刻它相对于本车的速度为{front[x][1]}")
#                     msg.distance_r=x
#                     msg.velocity_r=front[x][1]
#                     pub.publish(msg)
#                     front={}
            


# # Close the socket (this will not be reached in this example)
# socket.close()