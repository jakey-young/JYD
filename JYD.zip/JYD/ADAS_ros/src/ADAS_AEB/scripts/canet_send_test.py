#!/usr/bin/env python3




import rospy
from ADAS_AEB.msg import aeb
import socket
msg = aeb()


def linear_trans(input_brake,input_throttle):
    hex_brake_max = "020000640000"
    hex_brake_min = "020000000000"

    hex_throttle_max = "FF"
    hex_throttle_min = "48"

    brake_value_max = int(hex_brake_max, 16)
    brake_value_min = int(hex_brake_min, 16)

    throttle_value_max = int(hex_throttle_max, 16)
    throttle_value_min = int(hex_throttle_min, 16)

    k_b = (brake_value_max - brake_value_min) / 100
    b_b = brake_value_min
    value_b = input_brake * k_b + b_b
    hex_value_b = hex(int(value_b))[2:]

    k_t = (throttle_value_max - throttle_value_min) / 100
    b_t = throttle_value_min
    value_t = (input_throttle * k_t + b_t) * 256 + 1
    hex_value_t = hex(int(value_t))[2:]
    return hex_value_b, hex_value_t

def byte_splice(byte_brake, byte_throttle):
    byte_brake_head = b'\x08\x00\x00\x01\x54\x00\x00'
    byte_throttle_head = b'\x08\x00\x00\x05\x01\x49\x00'
    concatenated_data_brake = byte_brake_head + byte_brake
    concatenated_data_throttle = byte_throttle_head + byte_throttle
    # print(concatenated_data_throttle)
    return concatenated_data_brake, concatenated_data_throttle

def can_send(send_brake,send_throttle):
    CANET_IP = "192.168.1.178"  # CANet通信IP
    CANET_PORT = 4001  # CANet端口号
    PC_IP = "192.168.1.102"  # 主机通信IP
    PC_PORT = 4001  # 主机端口号
    # Create a UDP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # Bind the socket to the PC IP and port
    # rospy.loginfo(send_brake)

    sock.bind((PC_IP, PC_PORT))
    sock.sendto(send_brake, (CANET_IP,CANET_PORT))
    sock.sendto(send_throttle, (CANET_IP,CANET_PORT))

def data_process(msg):
    brake = msg.brake
    throttle = msg.throttle
    hex_brake,hex_throttle = linear_trans(brake,throttle)
    print(hex_throttle)
    byte_brake = bytes.fromhex(hex_brake.zfill(12))
    byte_throttle = bytes.fromhex(hex_throttle.zfill(12))
    enb_flag = bytes([byte_throttle[-1] & 0x01])
    byte_throttle = byte_throttle[0:-1] + enb_flag
    print(byte_throttle)
    send_brake, send_throttle = byte_splice(byte_brake,byte_throttle)
    # print(send_brake)
    can_send(send_brake,send_throttle)
    

if __name__  == "__main__":
    rospy.init_node("canet_send_test")
    rospy.Subscriber("/throttle_signal",aeb,data_process)
    rospy.spin()