import struct
import serial
import math

def parse_and_trans(data):
    # 解析纬度、经度、海拔高度
    latitude = struct.unpack('<q', data[11:19])[0] * 1e-9
    longitude = struct.unpack('<q', data[19:27])[0] * 1e-9
    altitude = struct.unpack('<i', data[27:31])[0] * 1e-3

    a = 6378137.0  # 赤道半径
    f = 1 / 298.257223563  # 扁率
    b = (1 - f) * a  # 极半径
    e = math.sqrt((a * a - b * b) / (a * a))  # 第一偏心率
    N = a / math.sqrt(1 - e * e * math.sin(math.radians(latitude)) * math.sin(math.radians(latitude)))
    x = (N + altitude) * math.cos(math.radians(latitude)) * math.cos(math.radians(longitude))
    y = (N + altitude) * math.cos(math.radians(latitude)) * math.sin(math.radians(longitude))
    z = ((1 - e * e) * N + altitude) * math.sin(math.radians(latitude))

    print("当前地心地固坐标：", "x = ", x, "m", "y = ", y, "m", "z = ", z, "m")

if __name__ == '__main__':
    # 开启串口
    serialport = serial.Serial()
    buffer = b""
    try:
        # 设置串口属性并开启串口
        serialport.port = "/dev/ttyUSB0"
        # serialport.port = "COM4"
        serialport.baudrate = 230400
        serialport.timeout = 0.1
        serialport.open()
    except serial.SerialException as e:
        print("Unable to open serial port")

    # 检测串口是否已经打开，并给出提示信息
    if serialport.is_open:
        print("Serial port initialized")

    while True:
        # 处理串口发过来的数据
        data_size = serialport.in_waiting

        if data_size >= 64:
            buffer = serialport.read(data_size)
            gins_index = buffer.find(b'\xAC\xCA\x0C')

            # 处理GINS数据
            if gins_index != -1 and len(buffer[gins_index:]) >= 64:
                parse_and_trans(buffer[gins_index:gins_index + 64])
                buffer = buffer[gins_index + 64:]