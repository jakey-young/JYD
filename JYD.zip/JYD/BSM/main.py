import serial
import time

# 创建串口对象
ser = serial.Serial('/dev/ttyUSB1', 9600)  # 将 '/dev/ttyUSB0' 替换为你的串口设备路径

distance1 = 0
distance4 = 0

# 发送命令函数
def send_command1():
    command1 = [0x55, 0xAA, 0x01, 0x10, 0x10]
    ser.write(bytearray(command1))

def send_command4():
    command4 = [0x55, 0xAA, 0x01, 0x13, 0x13]
    ser.write(bytearray(command4))

while True:
    try:
        # 发送命令，1号探头探测左后方障碍物距离
        send_command1()
        time.sleep(0.3)
        # 等待数据返回
        if ser.in_waiting >= 7:
            # 读取返回的数据
            data1 = ser.read(7)
            # 提取1号结果探头
            distance1 = ((data1[4] << 8) | data1[5]) / 10
            if distance1 <= 20:
                print("Warning!!!左后方盲区距离障碍物过近!!!距离为：", distance1, "cm")
            else:
                print("左后方盲区距离障碍物较远，距离为：", distance1, "cm")
        # 发送命令，4号探头探测右后方障碍物距离
        send_command4()
        time.sleep(0.3)
        # 等待数据返回
        if ser.in_waiting >= 7:
            # 读取返回的数据
            data2 = ser.read(7)
            # 提取4号结果探头
            distance4 = ((data2[4] << 8) | data2[5]) / 10
            if distance4 <= 20:
                print("Warning!!!右后方盲区距离障碍物过近!!!距离为：", distance4, "cm")
            else:
                print("右后方盲区距离障碍物较远，距离为：", distance4, "cm")
    finally:
        time.sleep(0.5)
        print("----------------------------------")
        time.sleep(0.5)
# 关闭串口
ser.close()
