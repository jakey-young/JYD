
"use strict";

let glosa = require('./glosa.js');

module.exports = {
  glosa: glosa,
};
