#! /usr/bin/env python3

import socket
import time
import rospy
from glosa.msg import glosa

rospy.init_node("light_receive")
msg = glosa()
pub = rospy.Publisher('/green_light_time', glosa, queue_size=10)

PC_IP = "192.168.54.75"
PC_PORT = 8000

# 创建TCP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定IP地址和端口号
server_socket.bind((PC_IP, PC_PORT))

# 监听连接
server_socket.listen(1)
rospy.loginfo('服务器已启动，等待客户端连接...')

# 接受客户端连接
client_socket, addr = server_socket.accept()
rospy.loginfo('客户端已连接: %s', addr)
print(1)
# # 循环接收数据
# while True:
#     data = client_socket.recv(1024)
#     if not data:
#         break
#     if data.hex()[3] == "b":    # 接收数据的第二字节0b表示东西方向，0a南北方向（使用东西方向）
#         continue

#     # 打印接收到的数据
#     print("此时绿灯剩余时间：", data[2])    # 考虑绿灯情况

# 车辆进入绿波带时运行程序，只接收一次绿灯时间
while not rospy.is_shutdown():
    data = client_socket.recv(100)
    if data.hex()[3] == "b":    # 接收数据的第二字节0b表示东西方向，0a南北方向（使用东西方向）
        green_light =  data[2]
        rospy.loginfo("当前绿灯剩余时间: %s", green_light) 
        msg.green_light_time = green_light
        pub.publish(msg)

        # break

# 打印并发布接收到的数据
server_socket.close()

