#! /usr/bin/env python3

import socket
import time
import rospy
from glosa.msg import glosa

rospy.init_node("speed_receive")
msg = glosa()
pub = rospy.Publisher('/car_speed', glosa, queue_size=10)

PC_IP = "192.168.1.102"
PC_PORT = 4001

# 创建UDP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 绑定IP地址和端口号
sock.bind((PC_IP, PC_PORT))



while not rospy.is_shutdown():
    # Receive data from the CAN-to-Ethernet device
    data, addr = sock.recvfrom(100)  # Adjust buffer size if necessary
    
    # Check if the received message has a valid length for parsing
    if len(data) >= 13:
        # Parse the received data
        frame = {
            'ID': int.from_bytes(data[1:5], byteorder='big'),
            'data': data[5:13],
        }

        if frame['ID'] == 1283:
            #print(data)
            car_spd_l = int.from_bytes(frame['data'][0:2], byteorder='big') * 0.1
            car_spd_r = int.from_bytes(frame['data'][2:4], byteorder='big') * 0.1
            car_speed = (car_spd_l + car_spd_r) / 2
            # rospy.loginfo("当前车速: %s", car_speed)
            msg.car_speed = car_speed
            pub.publish(msg)
            # break


# 打印并发布接收到的数据
sock.close()
