#!/usr/bin/env python3
from glosa.msg import glosa
import rospy
THROTTLE = 30
pub = rospy.Publisher('/throttle_signal', glosa, queue_size=10)

            
if __name__ == "__main__":
    rospy.init_node("throttle_contral")
    msg = glosa()
    msg.flag = 2
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        rospy.loginfo(msg.flag)
        pub.publish(msg)
        rate.sleep()  #休眠