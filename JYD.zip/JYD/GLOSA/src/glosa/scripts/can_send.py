#!/usr/bin/env python3

import rospy

from glosa.msg import glosa
import socket

send_buf = bytearray(13)
msg = glosa()
THROTTLE = [20,100]
FLAG = 2
def linear_trans(input_brake,input_throttle):
    hex_brake_max = "020000640000"
    hex_brake_min = "020000000000"

    hex_throttle_max = "FF"
    hex_throttle_min = "00"

    brake_value_max = int(hex_brake_max, 16)
    brake_value_min = int(hex_brake_min, 16)

    throttle_value_max = int(hex_throttle_max, 16)
    throttle_value_min = int(hex_throttle_min, 16)

    k_b = (brake_value_max - brake_value_min) / 100
    b_b = brake_value_min
    value_b = input_brake * k_b + b_b
    hex_value_b = hex(int(value_b))[2:]

    k_t = (throttle_value_max - throttle_value_min) / 100
    b_t = throttle_value_min
    value_t = input_throttle * k_t + b_t
    hex_value_t = hex(int(value_t))
    return hex_value_b, hex_value_t

def byte_splice(byte_brake):
    byte_brake_head = b'\x08\x00\x00\x01\x54\x00\x00'
    concatenated_data_brake = byte_brake_head + byte_brake
    return concatenated_data_brake

def can_send(send_brake,send_throttle):
    CANET_IP = "192.168.1.178"  # CANet通信IP
    CANET_PORT = 4001  # CANet端口号
    PC_IP  = "192.168.1.102"  # 主机通信IP
    PC_PORT = 5001  # 主机端口号
    # Create a UDP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # Bind the socket to the PC IP and port
    rospy.loginfo('刹车：%s',send_brake)
    rospy.loginfo('油门：%s',send_throttle)
    sock.bind((PC_IP, PC_PORT))
    sock.sendto(send_brake, (CANET_IP,CANET_PORT))
    sock.sendto(send_throttle, (CANET_IP,CANET_PORT))


def throttle_buff(hex_throttle):
    send_buf[0] = 0x08
    send_buf[1] = 0x00
    send_buf[2] = 0x00
    send_buf[3] = 0x05
    send_buf[4] = 0x01
    send_buf[5] = 0x09
    send_buf[6] = int(hex_throttle, 16)
    send_buf[7] = 0x00
    send_buf[8] = 0x00
    send_buf[9] = 0x00
    send_buf[10] = 0x00
    send_buf[11] = 0x10
    send_buf[12] = 0x00

    return bytes(send_buf)

def data_process(msg):
    # if msg.flag == 0 :
    #        throttle = b'\x08\x00\x00\x05\x01\x09\x50\x00\x00\x00\x00\x10\x00'
    # else:
    #     throttle = b'\x08\x00\x00\x05\x01\x09\x60\x00\x00\x00\x00\x10\x00'
    global FLAG
 
    if FLAG == 0 :
        throttle = 50
        brake = 0
    elif  FLAG  ==1:
        throttle = 60
        brake = 0
    elif  FLAG  ==2:
        throttle = 0
        brake = 70
    rospy.loginfo(FLAG)
    FLAG = msg.flag
    hex_brake,hex_throttle = linear_trans(brake,throttle)
    byte_brake = bytes.fromhex(hex_brake.zfill(12))
    send_throttle = throttle_buff(hex_throttle)
    # print(byte_brake)
    send_brake = byte_splice(byte_brake)
    # print(send_throttle.value)
    # # print(send_brake)
    rospy.loginfo("当前油门: %s     当前刹车:%s", throttle, brake)
    can_send(send_brake,send_throttle)
    

if __name__  == "__main__":
    rospy.init_node("canet_send")
    rospy.Subscriber("/decision",glosa,data_process)
    rospy.spin()
