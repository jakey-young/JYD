#! /usr/bin/env python3

import rospy
from glosa.msg import glosa
LIGHT_DIS = 0
SPEED = 0
def self_car_speed(msg):
    global SPEED
    SPEED = msg.car_speed

def light_distance(msg):
    global LIGHT_DIS
    LIGHT_DIS = msg.distance_r
    
def green_light(msg):
    global SPEED
    green_light_time = msg.green_light_time
    car_speed = SPEED
    rospy.loginfo("当前绿灯剩余时间: %s", green_light_time) 
    if green_light_time > 0:
        min_speed = LIGHT_DIS /green_light_time
        if car_speed >= min_speed:
            msg.flag = 0
            # msg.brake = 0
            # rospy.loginfo("请保持当前车速行驶...")
        else:
            msg.flag = 1
            # msg.brake = 0
            # rospy.loginfo("当前车速不能在红灯前通过路口，正在加速...")
    elif green_light_time == 0:
        msg.flag = 2
        # msg.brake = 60
    print(msg.flag)
    pub.publish(msg)






if __name__ == '__main__':
    # 初始化订阅节点
    rospy.init_node('glosa_decision') 
    msg = glosa()
    pub = rospy.Publisher("/decision", glosa, queue_size=1)
    # 订阅当前速度和当前绿灯剩余时间
    rospy.Subscriber("/car_speed", glosa, self_car_speed)
    rospy.Subscriber("/mmlidar_msg", glosa, light_distance)
    rospy.Subscriber("/green_light_time", glosa, green_light)
    rospy.spin()
